"""
Frontend do chatbot usando Streamlit.
Gerencia a interface e interações com o usuário.
"""

import streamlit as st
from back.main import generate_response
from back.utils import info_logger
from back.agent.prompt_engineering import log_process_data
import time

st.title("Chat Bot")
cont = st.container()

if "messages" not in st.session_state:
    st.session_state["messages"] = [
        {"role": "assistant", "content": "Olá! Como posso ajudar você hoje?"}
    ]

with cont:
    for m in st.session_state["messages"]:
        if m["role"] == 'user':
            st.chat_message("user").write(m["content"])
        elif m["role"] == "assistant":
            st.chat_message("assistant").write(m["content"])

prompt = st.chat_input("Digite sua mensagem:")

if prompt:
    st.session_state["messages"].append({
        "role": "user",
        "content": prompt
    })
    st.chat_message("user").write(prompt)

    bot_message_placeholder = st.chat_message("assistant")
    with bot_message_placeholder:
        
        response_slot = st.empty()
        spinner_slot = bot_message_placeholder.container()  # Slot para o spinner
          # Slot para a resposta final

        with spinner_slot:
            # st.markdown("⏳ Processando...")  # Exibe o spinner
            with st.spinner("Gerando resposta..."):
                # time.sleep(2)  # Simula processamento
                response = generate_response(prompt)

        spinner_slot.empty()  # Remove o spinner do slot
        response_slot.write(response)  # Insere a resposta no slot

    st.session_state["messages"].append({
        "role": "assistant",
        "content": response
    })

st.markdown(
    """
    <style>
    @media only screen and (max-width: 600px) {
        .st-emotion-cache-1eo1tir {
            padding-left: 0px;
            padding-right: 0px;
        }
    }
    </style>
    """,
    unsafe_allow_html=True
)
