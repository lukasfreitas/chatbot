import pytest
from unittest.mock import patch
from back.agent.prompt_engineering import PromptEngineeringLayer

@pytest.fixture
def prompt_layer():
    """Fixture que inicializa uma instância do PromptEngineeringLayer."""
    return PromptEngineeringLayer()

def test_process_user_message_information(prompt_layer):
    with patch('back.agent.general_flow.get_groq_client') as mock_client:  # Alterado para `get_groq_client`
        mock_client.return_value.chat.completions.create.return_value.choices[0].message.content = "1"
        response = prompt_layer.process_user_message("A capital do Brasil é Brasília.")
        assert response["intention"] == "General Flow"  # Ajustado se necessário


def test_process_user_message_preference(prompt_layer):
    with patch('back.agent.prompt_engineering.client.chat.completions.create') as mock_completion:
        mock_completion.return_value.choices[0].message.content = "2"

        response = prompt_layer.process_user_message("Prefiro respostas curtas.")

        assert response["intention"] == "General Flow"
        assert response["response"] == "Preferência armazenada com sucesso."

def test_handle_history_question(prompt_layer):
    # Simula histórico de mensagens
    prompt_layer.memory.chat_memory.messages = [
        {"role": "user", "content": "Primeira mensagem de teste."},
        {"role": "assistant", "content": "Resposta à primeira mensagem."}
    ]

    response = prompt_layer.handle_history_question("Qual foi minha primeira mensagem?")

    assert response == "Sua primeira mensagem foi: 'Primeira mensagem de teste.'"
