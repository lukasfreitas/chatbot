import pytest
from unittest.mock import patch
from back.agent.general_flow import general_flow

@pytest.fixture
def mock_groq_client():
    with patch('back.agent.general_flow.client') as mock_client:
        yield mock_client

def test_general_flow_response(mock_groq_client):
    # Configura o mock para retornar uma resposta específica
    mock_groq_client.chat.completions.create.return_value.choices[0].message.content = "Resposta simulada"

    prompt = "Olá, como você está?"
    response = general_flow(prompt)

    # Verifica se a resposta é a esperada
    assert response == "Resposta simulada"
    # Verifica se o método do cliente foi chamado corretamente
    mock_groq_client.chat.completions.create.assert_called_once()
