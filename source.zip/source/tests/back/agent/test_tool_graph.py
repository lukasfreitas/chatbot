import pytest
from unittest.mock import patch
from back.agent.tool_graph import configure_tool_graph

@pytest.fixture
def mock_prompt_layer():
    with patch('back.agent.tool_graph.prompt_layer') as mock_layer:
        yield mock_layer

def test_configure_tool_graph_general_flow(mock_prompt_layer):
    mock_prompt_layer.process_user_message.return_value = {
        "intention": "General Flow",
        "response": "Resposta do fluxo geral."
    }

    with patch('back.agent.tool_graph.general_flow') as mock_general_flow:
        mock_general_flow.return_value = "Resposta do general_flow"

        prompt = "Qual é o clima hoje?"
        response = configure_tool_graph(prompt)

        assert response == "Resposta do general_flow"
        mock_general_flow.assert_called_with(prompt)

def test_configure_tool_graph_rag_flow(mock_prompt_layer):
    mock_prompt_layer.process_user_message.return_value = {
        "intention": "RAG Flow",
        "response": "Informação armazenada com sucesso."
    }

    with patch('back.agent.tool_graph.rag_flow') as mock_rag_flow:
        mock_rag_flow.return_value = "Resposta do rag_flow"

        prompt = "A capital da França é Paris."
        response = configure_tool_graph(prompt)

        assert response == "Resposta do rag_flow"
        mock_rag_flow.assert_called_with(prompt)
