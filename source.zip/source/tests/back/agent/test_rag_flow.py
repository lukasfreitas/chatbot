import pytest
from unittest.mock import patch
from back.agent.rag_flow import rag_flow

@pytest.fixture
def mock_tavily_client():
    with patch('back.agent.rag_flow.get_tavily_client') as mock_client:
        yield mock_client

@pytest.fixture
def mock_pinecone_index():
    with patch('back.agent.rag_flow.get_index') as mock_index:
        yield mock_index

def test_rag_flow(mock_tavily_client, mock_pinecone_index):
    mock_tavily_client.return_value.get_search_context.return_value = "Contexto simulado"
    mock_pinecone_index.return_value.query.return_value = {
        'matches': [
            {'score': 0.9, 'id': '1', 'metadata': {'content': 'Resultado 1'}},
            {'score': 0.8, 'id': '2', 'metadata': {'content': 'Resultado 2'}}
        ]
    }

    prompt = "Pergunta de teste"
    response = rag_flow(prompt)

    assert "Resultado 1" in response
    assert "Resultado 2" in response
    # Verifica se os métodos foram chamados corretamente
    mock_tavily_client.return_value.get_search_context.assert_called_with(query=prompt)
    assert mock_pinecone_index.return_value.query.called
