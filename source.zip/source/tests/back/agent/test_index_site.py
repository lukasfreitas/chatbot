import pytest
from unittest.mock import patch
from back.agent.index_site import index_site_content

@pytest.fixture
def mock_tavily_client():
    with patch('back.agent.index_site.get_tavily_client') as mock_client:
        yield mock_client

@pytest.fixture
def mock_pinecone_index():
    with patch('back.agent.index_site.get_index') as mock_index:
        yield mock_index

def test_index_site_content(mock_tavily_client, mock_pinecone_index):
    mock_tavily_client.return_value.get_search_context.return_value = "Contexto simulado"
    mock_pinecone_index.return_value.upsert.return_value = None

    query = "Teste de indexação"
    links = ["https://exemplo.com"]

    index_site_content(query, links)

    # Verifica se o TavilyClient foi chamado corretamente
    mock_tavily_client.return_value.get_search_context.assert_called_with(
        query="Teste de indexação\n\nLinks para referência:\n- https://exemplo.com"
    )
    # Verifica se o Pinecone index foi chamado para upsert
    assert mock_pinecone_index.return_value.upsert.called
