import os
import pytest
from back.config import get_env_variable

def test_get_env_variable(monkeypatch):
    monkeypatch.setenv('TEST_VARIABLE', 'test_value')
    assert get_env_variable('TEST_VARIABLE') == 'test_value'

def test_get_env_variable_default():
    assert get_env_variable('NON_EXISTENT_VARIABLE', default='default_value') == 'default_value'

def test_get_env_variable_exception():
    with pytest.raises(ValueError):
        get_env_variable('NON_EXISTENT_VARIABLE')
