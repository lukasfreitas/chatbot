import pytest
from unittest.mock import patch
from back.main import generate_response

@pytest.fixture
def mock_configure_tool_graph():
    with patch('back.main.configure_tool_graph') as mock_graph:
        yield mock_graph

def test_generate_response(mock_configure_tool_graph):
    mock_configure_tool_graph.return_value = "Resposta gerada"

    prompt = "Olá, mundo!"
    response = generate_response(prompt)

    assert response == "Resposta gerada"
    mock_configure_tool_graph.assert_called_with(prompt)
