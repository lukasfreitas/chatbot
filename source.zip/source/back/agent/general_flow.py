# source/back/agent/general_flow.py
"""
Gerenciamento do fluxo geral do agente.
Implementa interações genéricas com o modelo.
"""

from back.config import GROQ_API_KEY, MODEL_ID
from groq import Groq

def create_general_chain():
    """
    Cria uma instância do cliente Groq com a chave de API configurada.
    """
    client = Groq(api_key=GROQ_API_KEY)
    return client

client = create_general_chain()

def get_groq_client():
    """
    Retorna a instância do cliente Groq.
    """
    return client

def general_flow(prompt):
    """
    Gera uma resposta baseada no prompt fornecido.
    Utiliza o modelo definido no ambiente para completar as interações.
    """
    client_instance = get_groq_client()
    chat_completion = client_instance.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": prompt,
            }
        ],
        model=MODEL_ID,
    )
    return chat_completion.choices[0].message.content
