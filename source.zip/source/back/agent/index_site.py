"""
Gerenciamento de indexação de conteúdo e consulta com integração ao fluxo de RAG.
"""

from back.config import INDEX_NAME
from back.pinecone_client import get_index
from back.tavily_client import get_tavily_client
from .rag_flow import rag_flow


def clean_id(text):
    """
    Limpa o ID removendo caracteres especiais e substituindo-os por '_'.

    Args:
        text (str): Texto a ser limpo.

    Returns:
        str: Texto limpo.
    """
    return ''.join(char if char.isalnum() else '_' for char in text)


def index_site_content(prompt, urls_to_search):
    """
    Indexa o conteúdo das URLs fornecidas e retorna uma resposta baseada no RAG Flow.

    Args:
        prompt (str): Prompt fornecido pelo usuário.
        urls_to_search (list): URLs a serem indexadas.

    Returns:
        str: Resposta gerada com base no conteúdo indexado.
    """
    tavily_client = get_tavily_client()

    # Extrai dados das URLs
    search_data = tavily_client.extract(urls=urls_to_search)
    if not search_data['results']:
        return "Não foi possível extrair informações das URLs fornecidas."

    # Indexa o conteúdo extraído no Pinecone
    index = get_index(INDEX_NAME)
    for result in search_data['results']:
        raw_content = result.get('raw_content', '')
        vector_id = clean_id(result.get('url', 'unknown'))
        embedding = rag_flow(prompt, urls_to_search)  # Use o fluxo RAG para embeddings
        metadata = {
            "url": result.get('url', 'unknown'),
            "content": raw_content
        }
        index.upsert([(vector_id, embedding, metadata)])

    # Use o RAG Flow para gerar a resposta com base no prompt
    response = rag_flow(prompt, urls_to_search)
    return response
